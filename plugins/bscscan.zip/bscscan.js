var fetch = global.nodemodule["node-fetch"];
var api = ["11ZMWNGPT2D66XIIBIKIVN1RDBRT63P6XC", "9WX99E9A3DK3P8Y26NAX1C6U3PYRHVQJ3D", "PQ5SHKDKI47CUW7SGF2DJIFM6F1P4TTKCR"]; //Created : 09/06/2021 | FuryCS Birthday wtf
var bscscan = async function(type, data) {
    var text = encodeURIComponent(data.args.slice(1).join(" "));
	if(text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "bscscan <wallet>"
		}
	} else {
		try {
		var fetchdata = await fetch(`https://api.bscscan.com/api?module=account&action=balance&address=${text}&tag=latest&apikey=${api[Math.floor(Math.random() * api.length)]}`);
		var jsondatax = await fetchdata.json();
		var jsondata = jsondatax.data || {};
		var data1 = jsondata.result || {};
		return {
			handler: "internal",
			data: `Balance: ${data1}`
        }
            } catch(ex) {data.log(ex)}
		}
    } 

module.exports = {
	bscscan: bscscan
}