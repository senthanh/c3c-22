var fetch = global.nodemodule["node-fetch"];

var discord = function discord(type, data) {
	(async function () {
		var returntext = `Discord bot: discord.com/api/oauth2/authorize?client_id=718418151032881243&permissions=8&scope=bot
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	discord: discord
}