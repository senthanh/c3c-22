var fetch = global.nodemodule["node-fetch"];
var streamBuffers = global.nodemodule["stream-buffers"];
var path = global.nodemodule["path"];
var wait = global.nodemodule["wait-for-stuff"];
var r = ["rushia"];
var p = ["pekora"];
var c = ["coco"];
var g = ["gura"];
var m = ["marine"];
var random = ["rushia", "pekora", "coco", "gura", "marine"];

var hololive = async function(type, data) {
    var fetchjson = await fetch(`https://img-hololive-api.up.railway.app/${random[Math.floor(Math.random() * random.length)]}`);
    var json = await fetchjson.json();
        var fetchimage = await fetch(json.url);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();
            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }

var rushia = async function(type, data) {
    var fetchjson = await fetch(`https://img-hololive-api.up.railway.app/${r}`);
    var json = await fetchjson.json();
        var fetchimage = await fetch(json.url);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();
            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }
        var pekora = async function(type, data) {
    var fetchjson = await fetch(`https://img-hololive-api.up.railway.app/${p}`);
    var json = await fetchjson.json();
        var fetchimage = await fetch(json.url);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();
            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }

        var peko = async function(type, data) {
            var fetchjson = await fetch(`https://img-hololive-api.up.railway.app/${p}`);
            var json = await fetchjson.json();
                var fetchimage = await fetch(json.url);
                var buffer = await fetchimage.buffer();
                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                        frequency: 1,
                        chunkSize: 8192
                    });
                    imagesx.path = 'image.png';
                    imagesx.put(buffer);
                    imagesx.stop();
                    return {
                        handler: "internal",
                        data: {
                            attachment: ([imagesx])
                        }
                    }
                }
var coco = async function(type, data) {
    var fetchjson = await fetch(`https://img-hololive-api.up.railway.app/${c}`);
    var json = await fetchjson.json();
        var fetchimage = await fetch(json.url);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();
            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }
        var gura = async function(type, data) {
            var fetchjson = await fetch(`https://img-hololive-api.up.railway.app/${g}`);
            var json = await fetchjson.json();
                var fetchimage = await fetch(json.url);
                var buffer = await fetchimage.buffer();
                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                        frequency: 1,
                        chunkSize: 8192
                    });
                    imagesx.path = 'image.png';
                    imagesx.put(buffer);
                    imagesx.stop();
                    return {
                        handler: "internal",
                        data: {
                            attachment: ([imagesx])
                        }
                    }
                }
                        var marine = async function(type, data) {
                            var fetchjson = await fetch(`https://img-hololive-api.up.railway.app/${m}`);
                            var json = await fetchjson.json();
                                var fetchimage = await fetch(json.url);
                                var buffer = await fetchimage.buffer();
                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                        frequency: 1,
                                        chunkSize: 8192
                                    });
                                    imagesx.path = 'image.png';
                                    imagesx.put(buffer);
                                    imagesx.stop();
                                    return {
                                        handler: "internal",
                                        data: {
                                            attachment: ([imagesx])
                                        }
                                    }
                                }
                                module.exports = {
                                    hololive: hololive,
                                    rushia : rushia,
                                    pekora : pekora,
                                    peko : peko,
                                    coco : coco,
                                    gura : gura,
                                    marine : marine
                                }