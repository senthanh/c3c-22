var fetch = global.nodemodule["node-fetch"];
var streamBuffers = global.nodemodule["stream-buffers"];
var path = global.nodemodule["path"];
var wait = global.nodemodule["wait-for-stuff"];
var text = ["v2"];

    var kissgif = async function(type, data) {
    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/kiss`);
    var json = await fetchjson.json();
        var fetchimage = await fetch(json.url);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();
            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }
        var huggif = async function(type, data) {
    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/hug`);
    var json = await fetchjson.json();
        var fetchimage = await fetch(json.url);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();
            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }

var Random_hentai_gif = async function(type, data) {
    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/Random_hentai_gif`);
    var json = await fetchjson.json();
        var fetchimage = await fetch(json.url);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();
            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }
        var solog = async function(type, data) {
            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/solog`);
            var json = await fetchjson.json();
                var fetchimage = await fetch(json.url);
                var buffer = await fetchimage.buffer();
                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                        frequency: 1,
                        chunkSize: 8192
                    });
                    imagesx.path = 'image.png';
                    imagesx.put(buffer);
                    imagesx.stop();
                    return {
                        handler: "internal",
                        data: {
                            attachment: ([imagesx])
                        }
                    }
                }
                var smug = async function(type, data) {
                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/smug`);
                    var json = await fetchjson.json();
                        var fetchimage = await fetch(json.url);
                        var buffer = await fetchimage.buffer();
                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                frequency: 1,
                                chunkSize: 8192
                            });
                            imagesx.path = 'image.png';
                            imagesx.put(buffer);
                            imagesx.stop();
                            return {
                                handler: "internal",
                                data: {
                                    attachment: ([imagesx])
                                }
                            }
                        }
                        var feet = async function(type, data) {
                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/feet`);
                            var json = await fetchjson.json();
                                var fetchimage = await fetch(json.url);
                                var buffer = await fetchimage.buffer();
                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                        frequency: 1,
                                        chunkSize: 8192
                                    });
                                    imagesx.path = 'image.png';
                                    imagesx.put(buffer);
                                    imagesx.stop();
                                    return {
                                        handler: "internal",
                                        data: {
                                            attachment: ([imagesx])
                                        }
                                    }
                                }
                                var smallboobs = async function(type, data) {
                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/smallboobs`);
                                    var json = await fetchjson.json();
                                        var fetchimage = await fetch(json.url);
                                        var buffer = await fetchimage.buffer();
                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                frequency: 1,
                                                chunkSize: 8192
                                            });
                                            imagesx.path = 'image.png';
                                            imagesx.put(buffer);
                                            imagesx.stop();
                                            return {
                                                handler: "internal",
                                                data: {
                                                    attachment: ([imagesx])
                                                }
                                            }
                                        }
                                        var lewdkemo = async function(type, data) {
                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/lewdkemo`);
                                            var json = await fetchjson.json();
                                                var fetchimage = await fetch(json.url);
                                                var buffer = await fetchimage.buffer();
                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                        frequency: 1,
                                                        chunkSize: 8192
                                                    });
                                                    imagesx.path = 'image.png';
                                                    imagesx.put(buffer);
                                                    imagesx.stop();
                                                    return {
                                                        handler: "internal",
                                                        data: {
                                                            attachment: ([imagesx])
                                                        }
                                                    }
                                                }
                                                var woof = async function(type, data) {
                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/woof`);
                                                    var json = await fetchjson.json();
                                                        var fetchimage = await fetch(json.url);
                                                        var buffer = await fetchimage.buffer();
                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                frequency: 1,
                                                                chunkSize: 8192
                                                            });
                                                            imagesx.path = 'image.png';
                                                            imagesx.put(buffer);
                                                            imagesx.stop();
                                                            return {
                                                                handler: "internal",
                                                                data: {
                                                                    attachment: ([imagesx])
                                                                }
                                                            }
                                                        }
                                                        var gasm = async function(type, data) {
                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/gasm`);
                                                            var json = await fetchjson.json();
                                                                var fetchimage = await fetch(json.url);
                                                                var buffer = await fetchimage.buffer();
                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                        frequency: 1,
                                                                        chunkSize: 8192
                                                                    });
                                                                    imagesx.path = 'image.png';
                                                                    imagesx.put(buffer);
                                                                    imagesx.stop();
                                                                    return {
                                                                        handler: "internal",
                                                                        data: {
                                                                            attachment: ([imagesx])
                                                                        }
                                                                    }
                                                                }
                                                                var solo = async function(type, data) {
                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/solo`);
                                                                    var json = await fetchjson.json();
                                                                        var fetchimage = await fetch(json.url);
                                                                        var buffer = await fetchimage.buffer();
                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                frequency: 1,
                                                                                chunkSize: 8192
                                                                            });
                                                                            imagesx.path = 'image.png';
                                                                            imagesx.put(buffer);
                                                                            imagesx.stop();
                                                                            return {
                                                                                handler: "internal",
                                                                                data: {
                                                                                    attachment: ([imagesx])
                                                                                }
                                                                            }
                                                                        }
                                                                        var goose = async function(type, data) {
                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/goose`);
                                                                            var json = await fetchjson.json();
                                                                                var fetchimage = await fetch(json.url);
                                                                                var buffer = await fetchimage.buffer();
                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                        frequency: 1,
                                                                                        chunkSize: 8192
                                                                                    });
                                                                                    imagesx.path = 'image.png';
                                                                                    imagesx.put(buffer);
                                                                                    imagesx.stop();
                                                                                    return {
                                                                                        handler: "internal",
                                                                                        data: {
                                                                                            attachment: ([imagesx])
                                                                                        }
                                                                                    }
                                                                                }
                                                                                var cuddle = async function(type, data) {
                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/cuddle`);
                                                                                    var json = await fetchjson.json();
                                                                                        var fetchimage = await fetch(json.url);
                                                                                        var buffer = await fetchimage.buffer();
                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                frequency: 1,
                                                                                                chunkSize: 8192
                                                                                            });
                                                                                            imagesx.path = 'image.png';
                                                                                            imagesx.put(buffer);
                                                                                            imagesx.stop();
                                                                                            return {
                                                                                                handler: "internal",
                                                                                                data: {
                                                                                                    attachment: ([imagesx])
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        var avatar = async function(type, data) {
                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/avatar`);
                                                                                            var json = await fetchjson.json();
                                                                                                var fetchimage = await fetch(json.url);
                                                                                                var buffer = await fetchimage.buffer();
                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                        frequency: 1,
                                                                                                        chunkSize: 8192
                                                                                                    });
                                                                                                    imagesx.path = 'image.png';
                                                                                                    imagesx.put(buffer);
                                                                                                    imagesx.stop();
                                                                                                    return {
                                                                                                        handler: "internal",
                                                                                                        data: {
                                                                                                            attachment: ([imagesx])
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                                var cum = async function(type, data) {
                                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/cum`);
                                                                                                    var json = await fetchjson.json();
                                                                                                        var fetchimage = await fetch(json.url);
                                                                                                        var buffer = await fetchimage.buffer();
                                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                frequency: 1,
                                                                                                                chunkSize: 8192
                                                                                                            });
                                                                                                            imagesx.path = 'image.png';
                                                                                                            imagesx.put(buffer);
                                                                                                            imagesx.stop();
                                                                                                            return {
                                                                                                                handler: "internal",
                                                                                                                data: {
                                                                                                                    attachment: ([imagesx])
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                        var les = async function(type, data) {
                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/les`);
                                                                                                            var json = await fetchjson.json();
                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                        frequency: 1,
                                                                                                                        chunkSize: 8192
                                                                                                                    });
                                                                                                                    imagesx.path = 'image.png';
                                                                                                                    imagesx.put(buffer);
                                                                                                                    imagesx.stop();
                                                                                                                    return {
                                                                                                                        handler: "internal",
                                                                                                                        data: {
                                                                                                                            attachment: ([imagesx])
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                                var erokemo = async function(type, data) {
                                                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/erokemo`);
                                                                                                                    var json = await fetchjson.json();
                                                                                                                        var fetchimage = await fetch(json.url);
                                                                                                                        var buffer = await fetchimage.buffer();
                                                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                frequency: 1,
                                                                                                                                chunkSize: 8192
                                                                                                                            });
                                                                                                                            imagesx.path = 'image.png';
                                                                                                                            imagesx.put(buffer);
                                                                                                                            imagesx.stop();
                                                                                                                            return {
                                                                                                                                handler: "internal",
                                                                                                                                data: {
                                                                                                                                    attachment: ([imagesx])
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                        var bj = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/bj`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var pwankg = async function(type, data) {
                                                                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/pwankg`);
                                                                                                                                    var json = await fetchjson.json();
                                                                                                                                        var fetchimage = await fetch(json.url);
                                                                                                                                        var buffer = await fetchimage.buffer();
                                                                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                                frequency: 1,
                                                                                                                                                chunkSize: 8192
                                                                                                                                            });
                                                                                                                                            imagesx.path = 'image.png';
                                                                                                                                            imagesx.put(buffer);
                                                                                                                                            imagesx.stop();
                                                                                                                                            return {
                                                                                                                                                handler: "internal",
                                                                                                                                                data: {
                                                                                                                                                    attachment: ([imagesx])
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        var ero = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/ero`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var hololewd = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/hololewd`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var pat = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/pat`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var gecg = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/gecg`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var holo = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/holo`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var poke = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/poke`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var hentai = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/hentai`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var feed = async function(type, data) {
                                                                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/feed`);
                                                                                                                                    var json = await fetchjson.json();
                                                                                                                                        var fetchimage = await fetch(json.url);
                                                                                                                                        var buffer = await fetchimage.buffer();
                                                                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                                frequency: 1,
                                                                                                                                                chunkSize: 8192
                                                                                                                                            });
                                                                                                                                            imagesx.path = 'image.png';
                                                                                                                                            imagesx.put(buffer);
                                                                                                                                            imagesx.stop();
                                                                                                                                            return {
                                                                                                                                                handler: "internal",
                                                                                                                                                data: {
                                                                                                                                                    attachment: ([imagesx])
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        var fox_girl = async function(type, data) {
                                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/fox_girl`);
                                                                                                                                            var json = await fetchjson.json();
                                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                                        frequency: 1,
                                                                                                                                                        chunkSize: 8192
                                                                                                                                                    });
                                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                                    imagesx.put(buffer);
                                                                                                                                                    imagesx.stop();
                                                                                                                                                    return {
                                                                                                                                                        handler: "internal",
                                                                                                                                                        data: {
                                                                                                                                                            attachment: ([imagesx])
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                                var tits = async function(type, data) {
                                                                                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/tits`);
                                                                                                                                                    var json = await fetchjson.json();
                                                                                                                                                        var fetchimage = await fetch(json.url);
                                                                                                                                                        var buffer = await fetchimage.buffer();
                                                                                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                                                frequency: 1,
                                                                                                                                                                chunkSize: 8192
                                                                                                                                                            });
                                                                                                                                                            imagesx.path = 'image.png';
                                                                                                                                                            imagesx.put(buffer);
                                                                                                                                                            imagesx.stop();
                                                                                                                                                            return {
                                                                                                                                                                handler: "internal",
                                                                                                                                                                data: {
                                                                                                                                                                    attachment: ([imagesx])
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                        var nsfw_neko_gif = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/nsfw_neko_gif`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var eroyuri = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/eroyuri`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var holoero = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/holoero`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var pussy = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/pussy`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var lizard = async function(type, data) {
                                                                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/lizard`);
                                                                                                                                    var json = await fetchjson.json();
                                                                                                                                        var fetchimage = await fetch(json.url);
                                                                                                                                        var buffer = await fetchimage.buffer();
                                                                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                                frequency: 1,
                                                                                                                                                chunkSize: 8192
                                                                                                                                            });
                                                                                                                                            imagesx.path = 'image.png';
                                                                                                                                            imagesx.put(buffer);
                                                                                                                                            imagesx.stop();
                                                                                                                                            return {
                                                                                                                                                handler: "internal",
                                                                                                                                                data: {
                                                                                                                                                    attachment: ([imagesx])
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        var yuri_img = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/yuri`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var keta = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/keta`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var neko = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/neko`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                var hentai = async function(type, data) {
                                                                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/hentai`);
                                                                                                                                    var json = await fetchjson.json();
                                                                                                                                        var fetchimage = await fetch(json.url);
                                                                                                                                        var buffer = await fetchimage.buffer();
                                                                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                                frequency: 1,
                                                                                                                                                chunkSize: 8192
                                                                                                                                            });
                                                                                                                                            imagesx.path = 'image.png';
                                                                                                                                            imagesx.put(buffer);
                                                                                                                                            imagesx.stop();
                                                                                                                                            return {
                                                                                                                                                handler: "internal",
                                                                                                                                                data: {
                                                                                                                                                    attachment: ([imagesx])
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        var feetg = async function(type, data) {
                                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/feetg`);
                                                                                                                                            var json = await fetchjson.json();
                                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                                        frequency: 1,
                                                                                                                                                        chunkSize: 8192
                                                                                                                                                    });
                                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                                    imagesx.put(buffer);
                                                                                                                                                    imagesx.stop();
                                                                                                                                                    return {
                                                                                                                                                        handler: "internal",
                                                                                                                                                        data: {
                                                                                                                                                            attachment: ([imagesx])
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            
                                                                                                                                var eron = async function(type, data) {
                                                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/eron`);
                                                                                                                            var json = await fetchjson.json();
                                                                                                                                var fetchimage = await fetch(json.url);
                                                                                                                                var buffer = await fetchimage.buffer();
                                                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                                        frequency: 1,
                                                                                                                                        chunkSize: 8192
                                                                                                                                    });
                                                                                                                                    imagesx.path = 'image.png';
                                                                                                                                    imagesx.put(buffer);
                                                                                                                                    imagesx.stop();
                                                                                                                                    return {
                                                                                                                                        handler: "internal",
                                                                                                                                        data: {
                                                                                                                                            attachment: ([imagesx])
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
var erok = async function(type, data) {
    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/erok`);
    var json = await fetchjson.json();
        var fetchimage = await fetch(json.url);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();
            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }
        var baka = async function(type, data) {
            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/baka`);
            var json = await fetchjson.json();
                var fetchimage = await fetch(json.url);
                var buffer = await fetchimage.buffer();
                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                        frequency: 1,
                        chunkSize: 8192
                    });
                    imagesx.path = 'image.png';
                    imagesx.put(buffer);
                    imagesx.stop();
                    return {
                        handler: "internal",
                        data: {
                            attachment: ([imagesx])
                        }
                    }
                }
                var kemonomimi = async function(type, data) {
                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/kemonomimi`);
                    var json = await fetchjson.json();
                        var fetchimage = await fetch(json.url);
                        var buffer = await fetchimage.buffer();
                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                frequency: 1,
                                chunkSize: 8192
                            });
                            imagesx.path = 'image.png';
                            imagesx.put(buffer);
                            imagesx.stop();
                            return {
                                handler: "internal",
                                data: {
                                    attachment: ([imagesx])
                                }
                            }
                        }
                        var cum_jpg = async function(type, data) {
                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/cum_jpg`);
                            var json = await fetchjson.json();
                                var fetchimage = await fetch(json.url);
                                var buffer = await fetchimage.buffer();
                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                        frequency: 1,
                                        chunkSize: 8192
                                    });
                                    imagesx.path = 'image.png';
                                    imagesx.put(buffer);
                                    imagesx.stop();
                                    return {
                                        handler: "internal",
                                        data: {
                                            attachment: ([imagesx])
                                        }
                                    }
                                }
                                var nsfw_avatar = async function(type, data) {
                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/nsfw_avatar`);
                                    var json = await fetchjson.json();
                                        var fetchimage = await fetch(json.url);
                                        var buffer = await fetchimage.buffer();
                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                frequency: 1,
                                                chunkSize: 8192
                                            });
                                            imagesx.path = 'image.png';
                                            imagesx.put(buffer);
                                            imagesx.stop();
                                            return {
                                                handler: "internal",
                                                data: {
                                                    attachment: ([imagesx])
                                                }
                                            }
                                        }
                                        var erofeet = async function(type, data) {
                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/erofeet`);
                                            var json = await fetchjson.json();
                                                var fetchimage = await fetch(json.url);
                                                var buffer = await fetchimage.buffer();
                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                        frequency: 1,
                                                        chunkSize: 8192
                                                    });
                                                    imagesx.path = 'image.png';
                                                    imagesx.put(buffer);
                                                    imagesx.stop();
                                                    return {
                                                        handler: "internal",
                                                        data: {
                                                            attachment: ([imagesx])
                                                        }
                                                    }
                                                }
                                                var meow = async function(type, data) {
                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/meow`);
                                                    var json = await fetchjson.json();
                                                        var fetchimage = await fetch(json.url);
                                                        var buffer = await fetchimage.buffer();
                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                frequency: 1,
                                                                chunkSize: 8192
                                                            });
                                                            imagesx.path = 'image.png';
                                                            imagesx.put(buffer);
                                                            imagesx.stop();
                                                            return {
                                                                handler: "internal",
                                                                data: {
                                                                    attachment: ([imagesx])
                                                                }
                                                            }
                                                        }
                                                        var tickle = async function(type, data) {
                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/tickle`);
                                                            var json = await fetchjson.json();
                                                                var fetchimage = await fetch(json.url);
                                                                var buffer = await fetchimage.buffer();
                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                        frequency: 1,
                                                                        chunkSize: 8192
                                                                    });
                                                                    imagesx.path = 'image.png';
                                                                    imagesx.put(buffer);
                                                                    imagesx.stop();
                                                                    return {
                                                                        handler: "internal",
                                                                        data: {
                                                                            attachment: ([imagesx])
                                                                        }
                                                                    }
                                                                }
                                                                var blowjob = async function(type, data) {
                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/blowjob`);
                                                                    var json = await fetchjson.json();
                                                                        var fetchimage = await fetch(json.url);
                                                                        var buffer = await fetchimage.buffer();
                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                frequency: 1,
                                                                                chunkSize: 8192
                                                                            });
                                                                            imagesx.path = 'image.png';
                                                                            imagesx.put(buffer);
                                                                            imagesx.stop();
                                                                            return {
                                                                                handler: "internal",
                                                                                data: {
                                                                                    attachment: ([imagesx])
                                                                                }
                                                                            }
                                                                        }
                                                                        var kuni = async function(type, data) {
                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/kuni`);
                                                                            var json = await fetchjson.json();
                                                                                var fetchimage = await fetch(json.url);
                                                                                var buffer = await fetchimage.buffer();
                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                        frequency: 1,
                                                                                        chunkSize: 8192
                                                                                    });
                                                                                    imagesx.path = 'image.png';
                                                                                    imagesx.put(buffer);
                                                                                    imagesx.stop();
                                                                                    return {
                                                                                        handler: "internal",
                                                                                        data: {
                                                                                            attachment: ([imagesx])
                                                                                        }
                                                                                    }
                                                                                }
                                                                                var classic = async function(type, data) {
                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/classic`);
                                                                                    var json = await fetchjson.json();
                                                                                        var fetchimage = await fetch(json.url);
                                                                                        var buffer = await fetchimage.buffer();
                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                frequency: 1,
                                                                                                chunkSize: 8192
                                                                                            });
                                                                                            imagesx.path = 'image.png';
                                                                                            imagesx.put(buffer);
                                                                                            imagesx.stop();
                                                                                            return {
                                                                                                handler: "internal",
                                                                                                data: {
                                                                                                    attachment: ([imagesx])
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        var femdom = async function(type, data) {
                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/femdom`);
                                                                                            var json = await fetchjson.json();
                                                                                                var fetchimage = await fetch(json.url);
                                                                                                var buffer = await fetchimage.buffer();
                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                        frequency: 1,
                                                                                                        chunkSize: 8192
                                                                                                    });
                                                                                                    imagesx.path = 'image.png';
                                                                                                    imagesx.put(buffer);
                                                                                                    imagesx.stop();
                                                                                                    return {
                                                                                                        handler: "internal",
                                                                                                        data: {
                                                                                                            attachment: ([imagesx])
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                                var boobs = async function(type, data) {
                                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/boobs`);
                                                                                                    var json = await fetchjson.json();
                                                                                                        var fetchimage = await fetch(json.url);
                                                                                                        var buffer = await fetchimage.buffer();
                                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                                frequency: 1,
                                                                                                                chunkSize: 8192
                                                                                                            });
                                                                                                            imagesx.path = 'image.png';
                                                                                                            imagesx.put(buffer);
                                                                                                            imagesx.stop();
                                                                                                            return {
                                                                                                                handler: "internal",
                                                                                                                data: {
                                                                                                                    attachment: ([imagesx])
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                        var trap = async function(type, data) {
                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/trap`);
                                                                            var json = await fetchjson.json();
                                                                                var fetchimage = await fetch(json.url);
                                                                                var buffer = await fetchimage.buffer();
                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                        frequency: 1,
                                                                                        chunkSize: 8192
                                                                                    });
                                                                                    imagesx.path = 'image.png';
                                                                                    imagesx.put(buffer);
                                                                                    imagesx.stop();
                                                                                    return {
                                                                                        handler: "internal",
                                                                                        data: {
                                                                                            attachment: ([imagesx])
                                                                                        }
                                                                                    }
                                                                                }
                                                                                var lewd = async function(type, data) {
                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/lewd`);
                                                                            var json = await fetchjson.json();
                                                                                var fetchimage = await fetch(json.url);
                                                                                var buffer = await fetchimage.buffer();
                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                        frequency: 1,
                                                                                        chunkSize: 8192
                                                                                    });
                                                                                    imagesx.path = 'image.png';
                                                                                    imagesx.put(buffer);
                                                                                    imagesx.stop();
                                                                                    return {
                                                                                        handler: "internal",
                                                                                        data: {
                                                                                            attachment: ([imagesx])
                                                                                        }
                                                                                    }
                                                                                }
                                                                                var pussy_jpg = async function(type, data) {
                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/pussy_jpg`);
                                                                                    var json = await fetchjson.json();
                                                                                        var fetchimage = await fetch(json.url);
                                                                                        var buffer = await fetchimage.buffer();
                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                frequency: 1,
                                                                                                chunkSize: 8192
                                                                                            });
                                                                                            imagesx.path = 'image.png';
                                                                                            imagesx.put(buffer);
                                                                                            imagesx.stop();
                                                                                            return {
                                                                                                handler: "internal",
                                                                                                data: {
                                                                                                    attachment: ([imagesx])
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        var anal = async function(type, data) {
                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/anal`);
                                                                                            var json = await fetchjson.json();
                                                                                                var fetchimage = await fetch(json.url);
                                                                                                var buffer = await fetchimage.buffer();
                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                        frequency: 1,
                                                                                                        chunkSize: 8192
                                                                                                    });
                                                                                                    imagesx.path = 'image.png';
                                                                                                    imagesx.put(buffer);
                                                                                                    imagesx.stop();
                                                                                                    return {
                                                                                                        handler: "internal",
                                                                                                        data: {
                                                                                                            attachment: ([imagesx])
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                                var futanari = async function(type, data) {
                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/futanari`);
                                                                            var json = await fetchjson.json();
                                                                                var fetchimage = await fetch(json.url);
                                                                                var buffer = await fetchimage.buffer();
                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                        frequency: 1,
                                                                                        chunkSize: 8192
                                                                                    });
                                                                                    imagesx.path = 'image.png';
                                                                                    imagesx.put(buffer);
                                                                                    imagesx.stop();
                                                                                    return {
                                                                                        handler: "internal",
                                                                                        data: {
                                                                                            attachment: ([imagesx])
                                                                                        }
                                                                                    }
                                                                                }                         
                                                                                var ngif = async function(type, data) {
                                                                                    var fetchjson = await fetch(`https://nekos.life/api/${text}/img/ngif`);
                                                                                    var json = await fetchjson.json();
                                                                                        var fetchimage = await fetch(json.url);
                                                                                        var buffer = await fetchimage.buffer();
                                                                                            var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                frequency: 1,
                                                                                                chunkSize: 8192
                                                                                            });
                                                                                            imagesx.path = 'image.png';
                                                                                            imagesx.put(buffer);
                                                                                            imagesx.stop();
                                                                                            return {
                                                                                                handler: "internal",
                                                                                                data: {
                                                                                                    attachment: ([imagesx])
                                                                                                }
                                                                                            }
                                                                                        } 
                                                                                        var lewdk = async function(type, data) {
                                                                                            var fetchjson = await fetch(`https://nekos.life/api/${text}/img/lewdk`);
                                                                                            var json = await fetchjson.json();
                                                                                                var fetchimage = await fetch(json.url);
                                                                                                var buffer = await fetchimage.buffer();
                                                                                                    var imagesx = new streamBuffers.ReadableStreamBuffer({
                                                                                                        frequency: 1,
                                                                                                        chunkSize: 8192
                                                                                                    });
                                                                                                    imagesx.path = 'image.png';
                                                                                                    imagesx.put(buffer);
                                                                                                    imagesx.stop();
                                                                                                    return {
                                                                                                        handler: "internal",
                                                                                                        data: {
                                                                                                            attachment: ([imagesx])
                                                                                                        }
                                                                                                    }
                                                                                                }                                                                                      
                module.exports = {
                    Random_hentai_gif: Random_hentai_gif,
                    smug: smug,
                    baka: baka,
                    tickle: tickle,
                    poke: poke,
                    pat: pat,
                    neko: neko,
                    solog: solog,
                    meow: meow,
                    lizard: lizard,
                    feet: feet,
                    feed: feed,
                    cuddle: cuddle,
                    kemonomimi: kemonomimi,
                    holo: holo,
                    woof: woof,
                    goose: goose,
                    gecg: gecg,
                    avatar: avatar,
                    pussy: pussy,
                    feetg: feetg,
                    neko: neko,
                    erofeet: erofeet,
                    kuni: kuni,
                    femdom: femdom,
                    classic: classic,
                    boobs: boobs,
                    lewd: lewd,
                    anal: anal,
                    avatar: avatar,
                    yuri_img: yuri_img,
                    trap: trap,
                    tits: tits,
                    lewdkemo: lewdkemo,
                    lewdk: lewdk,
                    lewd: lewd,
                    kemonomimi: kemonomimi,
                    hololewd: hololewd,
                    keta: keta,
                    gasm: gasm,
                    smallboobs: smallboobs,
                    cum: cum,
                    cum_jpg: cum_jpg,
                    erokemo: erokemo,
                    ero: ero,
                    eroyuri: eroyuri,
                    holoero: holoero,
                    eron: eron,
                    erok: erok,
                    fox_girl: fox_girl,
                    nsfw_neko_gif: nsfw_neko_gif,
                    pussy_jpg: pussy_jpg,
                    nsfw_avatar: nsfw_avatar,
                    ngif: ngif,
                    futanari: futanari,
                    pwankg: pwankg,
                    kissgif: kissgif,
                    hentai: hentai,
                    huggif: huggif
                }