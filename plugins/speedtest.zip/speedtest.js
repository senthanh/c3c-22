var fast = global.nodemodule["fast-speedtest-api"];

var speedtest = async function(type, data) {
    var Test = new fast({
			token: "YXNkZmFzZGxmbnNkYWZoYXNkZmhrYWxm",
			verbose: false,
			timeout: 10000,
			https: true,
			urlCount: 5,
			bufferSize: 8,
			unit: fast.UNITS.Mbps
		});
		var resault = await Test.getSpeed();
        return {
            handler: `"internal",
            data: "=== Result ===" + 
			"\n- Speed: " + ${resault} + " Mbps"`
        }
}

module.exports = {
    speedtest: speedtest
}