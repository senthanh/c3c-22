var fetch = global.nodemodule["node-fetch"];

var vutru = function vutru(type, data) {
	(async function () {
		var returntext = `Tiêu đề : Vũ Trụ
Vũ trụ bao gồm tất cả các vật chất, năng lượng và không gian hiện có, được coi là một tổng thể. Vũ trụ hiện tại chưa xác định được kích thước, nó đã được mở rộng kể từ khi thành lập ở Big Bang khoảng 13 tỷ năm trước.
Hình học: Hầu như phẳng với sai số biên chỉ 0,4%
Khối lượng (vật chất thường): Ít nhất 1053 kg
Mật độ trung bình: 4,5 x 10−31 g/cm3
Nhiệt độ trung bình: 2,72548 K
Các thành phần chính: Vật chất (baryon) thường (4,9%), vật chất tối (26,8%), năng lượng tối (68,3%)
Tuổi: 13,799 ± 0,021 tỷ năm`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vutru\"mod lại của by Wua'n";

data.log(onLoadText);

}
module.exports = {
	vutru: vutru
}